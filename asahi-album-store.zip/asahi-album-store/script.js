// Asahi Records — storefront logic
const products = [
  {id:'a1', title:'Golden Hour', artist:'Asahi', price:159000, img:'assets/album1.svg'},
  {id:'a2', title:'Cocoa Dreams', artist:'Asahi', price:149000, img:'assets/album2.svg'},
  {id:'a3', title:'Soft Brown', artist:'Asahi', price:179000, img:'assets/album3.svg'},
  {id:'a4', title:'Oak & Vinyl', artist:'Asahi', price:169000, img:'assets/album4.svg'},
  {id:'a5', title:'Morning Coffee', artist:'Asahi', price:139000, img:'assets/album5.svg'},
  {id:'a6', title:'Warm Echoes', artist:'Asahi', price:189000, img:'assets/album6.svg'},
];

const cartKey = 'asahiCart';
let cart = JSON.parse(localStorage.getItem(cartKey) || '{}'); // {id: qty}

const grid = document.getElementById('productGrid');
const cartCount = document.getElementById('cartCount');
const cartDrawer = document.getElementById('cartDrawer');
const cartItemsEl = document.getElementById('cartItems');
const cartTotalEl = document.getElementById('cartTotal');
const backdrop = document.getElementById('backdrop');
const searchInput = document.getElementById('searchInput');
const sortSelect = document.getElementById('sortSelect');

function formatRupiah(num){
  return num.toLocaleString('id-ID', {style:'currency', currency:'IDR', maximumFractionDigits:0});
}

function saveCart(){
  localStorage.setItem(cartKey, JSON.stringify(cart));
  renderCartBadge();
}

function addToCart(id, qty=1){
  cart[id] = (cart[id]||0) + qty;
  saveCart();
  renderCart();
}

function setQty(id, qty){
  if(qty <= 0){ delete cart[id]; }
  else{ cart[id] = qty; }
  saveCart();
  renderCart();
}

function removeFromCart(id){
  delete cart[id];
  saveCart();
  renderCart();
}

function cartItems(){
  return Object.entries(cart).map(([id, qty])=>{
    const p = products.find(x=>x.id===id);
    return {...p, qty, line: p.price*qty};
  });
}

function renderCartBadge(){
  const count = Object.values(cart).reduce((a,b)=>a+b,0);
  cartCount.textContent = count;
}

function openCart(){ cartDrawer.classList.add('open'); cartDrawer.setAttribute('aria-hidden','false'); backdrop.hidden=false; }
function closeCart(){ cartDrawer.classList.remove('open'); cartDrawer.setAttribute('aria-hidden','true'); backdrop.hidden=true; }

function renderCart(){
  const items = cartItems();
  cartItemsEl.innerHTML = items.length? '' : '<p>Keranjang masih kosong.</p>';
  for(const it of items){
    const row = document.createElement('div');
    row.className='cart-item';
    row.innerHTML = \`
      <img src="\${it.img}" alt="Cover \${it.title}"/>
      <div>
        <div class="ci-title">\${it.title}</div>
        <div class="ci-artist">\${it.artist}</div>
        <div class="ci-price">\${formatRupiah(it.price)}</div>
      </div>
      <div class="ci-controls">
        <button class="icon-btn" aria-label="Kurangi" data-action="dec">−</button>
        <span>\${it.qty}</span>
        <button class="icon-btn" aria-label="Tambah" data-action="inc">＋</button>
        <button class="icon-btn" aria-label="Hapus" data-action="del">🗑</button>
      </div>
    \`;
    row.querySelector('[data-action="dec"]').onclick = ()=> setQty(it.id, it.qty-1);
    row.querySelector('[data-action="inc"]').onclick = ()=> setQty(it.id, it.qty+1);
    row.querySelector('[data-action="del"]').onclick = ()=> removeFromCart(it.id);
    cartItemsEl.appendChild(row);
  }
  const total = items.reduce((s,i)=>s+i.line,0);
  cartTotalEl.textContent = formatRupiah(total);
  renderCartBadge();
}

function renderProducts(list){
  grid.innerHTML = '';
  for(const p of list){
    const card = document.createElement('article');
    card.className='card';
    card.innerHTML = \`
      <img class="thumb" src="\${p.img}" alt="Sampul album \${p.title}"/>
      <div class="meta">
        <div class="title">\${p.title}</div>
        <div class="artist">\${p.artist}</div>
        <div class="price">\${formatRupiah(p.price)}</div>
      </div>
      <div class="qty-row">
        <button class="btn" data-action="dec">−</button>
        <input type="number" min="1" value="1" aria-label="Jumlah"/>
        <button class="btn" data-action="inc">＋</button>
      </div>
      <button class="btn add-btn">Tambah ke Keranjang</button>
    \`;
    const qtyInput = card.querySelector('input[type="number"]');
    card.querySelector('[data-action="dec"]').onclick = ()=>{ qtyInput.value = Math.max(1, parseInt(qtyInput.value||'1')-1); };
    card.querySelector('[data-action="inc"]').onclick = ()=>{ qtyInput.value = parseInt(qtyInput.value||'1')+1; };
    card.querySelector('.add-btn').onclick = ()=> addToCart(p.id, parseInt(qtyInput.value||'1'));
    grid.appendChild(card);
  }
}

// Search & sort
function applySearchSort(){
  const q = (searchInput.value||'').toLowerCase().trim();
  let list = products.filter(p=> p.title.toLowerCase().includes(q) || p.artist.toLowerCase().includes(q));
  const mode = sortSelect.value;
  if(mode==='price-asc') list.sort((a,b)=>a.price-b.price);
  if(mode==='price-desc') list.sort((a,b)=>b.price-a.price);
  if(mode==='title-asc') list.sort((a,b)=>a.title.localeCompare(b.title));
  if(mode==='title-desc') list.sort((a,b)=>b.title.localeCompare(a.title));
  renderProducts(list);
}

document.getElementById('cartButton').addEventListener('click', openCart);
document.getElementById('closeCart').addEventListener('click', closeCart);
document.getElementById('checkoutBtn').addEventListener('click', ()=>{
  const items = cartItems();
  if(!items.length){ alert('Keranjang masih kosong.'); return; }
  alert('Terima kasih! (Demo) — integrasi pembayaran bisa ditambahkan nanti.');
  cart = {}; saveCart(); renderCart();
});
backdrop.addEventListener('click', closeCart);
searchInput.addEventListener('input', applySearchSort);
sortSelect.addEventListener('change', applySearchSort);

// Init
document.getElementById('year').textContent = new Date().getFullYear();
renderProducts(products);
renderCart();
applySearchSort();
