# Asahi — Toko Album Musik (Aesthetic Coklat Muda)

Website statis sederhana untuk toko album musik milik **Asahi** dengan nuansa **coklat muda** dan fitur **keranjang** berbasis `localStorage` (tanpa backend). Cocok untuk di-host di **GitHub Pages**.

## Fitur
- Palet warna earthy (coklat muda / tan / cream).
- Grid produk responsif.
- Pencarian dan pengurutan (harga & judul).
- Keranjang: tambah/kurangi/hapus item, hitung total, simpan otomatis di `localStorage`.
- Tanpa library, murni HTML + CSS + JS — cepat & ringan.

## Struktur
```
asahi-album-store/
├── index.html
├── style.css
├── script.js
└── assets/
    ├── album1.svg … album6.svg
```

## Cara upload ke GitHub Pages
1. Ekstrak ZIP ini.
2. Buat repo baru di GitHub bernama misalnya `asahi-album-store`.
3. Upload semua file ke branch `main`.
4. Buka **Settings → Pages**.
5. Pada **Build and deployment** pilih:
   - *Source*: **Deploy from a branch**
   - *Branch*: **main** (folder root `/`)
6. Simpan. Tunggu sekitar 1 menit, lalu buka URL Pages yang muncul.

> Catatan: Tombol **Checkout** bersifat demo. Untuk pembayaran nyata, hubungkan ke layanan gateway (Midtrans/Xendit, dsb) dan kirim data keranjang via backend.
